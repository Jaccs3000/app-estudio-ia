const sqlite3 = require("sqlite3").verbose();

const db = new sqlite3.Database("./database.sqlite");

db.serialize(() => {
  db.run(`
    CREATE TABLE IF NOT EXISTS evaluaciones (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      tema TEXT,
      fecha TEXT,
      nota REAL
    )
  `);

  db.run(`
    CREATE TABLE IF NOT EXISTS preguntas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      evaluacion_id INTEGER,
      tipo TEXT,
      pregunta TEXT,
      opciones TEXT,
      respuesta_correcta TEXT,
      respuesta_usuario TEXT,
      argumento TEXT,
      es_correcta INTEGER,
      feedback TEXT
    )
  `);
});

module.exports = db;