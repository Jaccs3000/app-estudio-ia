console.log("🔥 server.js cargado");

require("dotenv").config();
const express = require("express");
const cors = require("cors");

// 🧠 Groq (compatible con OpenAI)
const OpenAI = require("openai");

const app = express();

app.use(cors());
app.use(express.json());

// 🔗 Inicializar base de datos
require("./database");

// 🤖 Cliente Groq
const client = new OpenAI({
  apiKey: process.env.GROQ_API_KEY,
  baseURL: "https://api.groq.com/openai/v1"
});

// ⚙️ CONFIG (según tu .md)
const MAX_REINTENTOS = 10;

// ------------------- ENDPOINTS -------------------

// Health check
app.get("/", (req, res) => {
  res.send("API funcionando 🚀");
});

// Generar preguntas
app.post("/generar", async (req, res) => {
  console.log("🔥 endpoint /generar ejecutado");

  const { temas } = req.body;

  // 🔴 Validación básica
  if (!temas || typeof temas !== "string") {
    return res.status(400).json({
      error: "Debes enviar el campo 'temas' como texto"
    });
  }

  let preguntas = null;

  // 🔁 REINTENTOS AUTOMÁTICOS (según .md)
  for (let intento = 1; intento <= MAX_REINTENTOS; intento++) {
    try {
      console.log(`🔁 Intento ${intento}`);

      const completion = await client.chat.completions.create({
        model: "llama-3.3-70b-versatile",
        messages: [
          {
            role: "user",
            content: `
Genera preguntas educativas en español para estudiantes sobre:
${temas}

Reglas:
- Máximo 20 preguntas
- Mezclar:
  - selección múltiple (4 opciones, una correcta)
  - verdadero/falso
- Incluir explicación breve en TODAS las preguntas
- NO repetir preguntas
- NO repetir opciones
- Nivel: primaria/secundaria

IMPORTANTE:
Devuelve SOLO JSON válido, sin texto adicional.

Formato:
[
  {
    "tipo": "multiple",
    "pregunta": "...",
    "opciones": ["A","B","C","D"],
    "correcta": "A",
    "explicacion": "..."
  },
  {
    "tipo": "vf",
    "pregunta": "...",
    "respuesta_correcta": true,
    "explicacion": "..."
  }
]
`
          }
        ],
      });

      let text = completion.choices[0].message.content;

      console.log("🧠 RESPUESTA IA:");
      console.log(text);

      // 🔥 LIMPIAR RESPUESTA
      text = text.replace(/```json|```/g, "").trim();

      // 🔥 PARSEAR JSON
      const parsed = JSON.parse(text);

      // 🔥 VALIDACIÓN BÁSICA
      if (!Array.isArray(parsed)) {
        throw new Error("El resultado no es un array");
      }

      preguntas = parsed;

      console.log("✅ JSON válido obtenido");
      break;

    } catch (error) {
      console.error(`❌ Error en intento ${intento}:`, error.message);

      // último intento → fallar
      if (intento === MAX_REINTENTOS) {
        return res.status(500).json({
          error: "No se pudo generar preguntas válidas tras varios intentos"
        });
      }
    }
  }

  // 🔥 RESPUESTA FINAL (CONTRATO DEL .MD)
  res.json({
    preguntas
  });
});

// ------------------- SERVER -------------------

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});